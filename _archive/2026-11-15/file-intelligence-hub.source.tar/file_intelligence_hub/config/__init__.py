"""Centralized hub configuration."""
