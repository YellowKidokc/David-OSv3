---
title: "Axiom Reclassification: Why 190 Axioms Are Not 190 Axioms"
subtitle: "Separating Primitives from Definitions, Theorems, Hypotheses, and Interpretations"
type: governance
version: v1.0
date: 2026-08-13
primary_author: "David Lowe | POF 2828"
ai_collaboration: "Claude Opus 4.6 (rewrite), original analysis by Atoxor Ltd."
status: "canon-candidate"
purpose: "Reclassify the 190-item proposition corpus by logical status. Stop calling non-axioms axioms. Enable axiom minimization."
supersedes: "All prior treatments of the 190 items as a flat axiom list"
---

# Axiom Reclassification: Why 190 Axioms Are Not 190 Axioms

## The Problem

The Theophysics corpus contains 190 items labeled "axioms." They are not all axioms. Calling them all axioms is the single largest architectural mistake in the project, and it must be corrected before the framework can be minimized, formalized, or defended.

An axiom is not just an important statement. An axiom is a statement deliberately left underived within a formal system — accepted as a starting point, not proven from anything else inside the system. It is the bedrock you build on without justifying from below.

The 190-item corpus contains items that are clearly not that. "Prayer as superposition" is not a starting point — it is a model analogy that requires independent definition of a state space and proof of correspondence. "Grace = negentropy" is not a primitive — it is a cross-domain interpretive identification. "Observation creates reality" is not something you leave underived — it is a physical and metaphysical hypothesis that requires careful empirical and interpretive qualification.

The consequence of calling all 190 items axioms is that the framework appears to rest on 190 independent assumptions. No serious framework needs 190 axioms. Euclidean geometry needs five. Peano arithmetic needs five. ZFC set theory needs nine. General relativity needs the equivalence principle and the Einstein field equations. If you have 190 axioms, you do not have a tight foundation. You have a list of things you think are important, mislabeled as a foundation.

The correction is not to throw things away. It is to classify them honestly.

## The Five Buckets

Every item in the 190-item corpus fits into one of five categories. The categories are mutually exclusive. An item cannot be in two buckets at once — if it seems to be, the item needs to be split into its component claims.

### Primitive (Postulate)

A statement accepted without derivation inside the system. You do not prove it from anything else in the framework. You start with it.

The test: if you tried to derive this from other items in the corpus, would the derivation be circular? If yes, it is primitive. If no, it belongs in a different bucket.

Candidate primitives (subject to further reduction):

- **Existence** — something exists rather than nothing
- **Distinction** — that which exists is distinguishable (not a featureless unity)
- **Relation** — distinguishable things stand in relation to each other
- **Orientation** — some states are better than others (the moral gradient, A4)
- **Truth** — there is a fact of the matter (correspondence is possible)

This list may reduce further. If Truth can be derived from Existence + Distinction (you need truth/falsity to even state that things are distinguishable), then it is not primitive — it is a theorem. If Orientation can be derived from Relation + a specific relational structure, it may not be primitive either. The goal is the smallest set of genuinely underived starting points.

The current estimate: **5-9 primitives**, not 190.

### Definition

Fixes the meaning of a symbol or concept. Does not assert an independent fact about reality. A definition is stipulative — it tells you what a word means inside the system, not what the world is like.

Examples from the corpus:

- "χ-field = the coherence landscape over the nine-coordinate state vector"
- "Coherence (C) = the wrapper function outside the product"
- "Φ = integrated information as defined by Tononi"
- "W = the mobility/coupling structure"
- "η = the open-source, forcing, or external-input slot"
- All symbol definitions in the Master Equation
- The D-series items (D2.1, D2.2, D19.1-D19.10)

Definitions are load-bearing but they are not axioms. They are conventions that make the formal language precise. Changing a definition does not refute the framework — it changes the notation. Definitions cannot be true or false — they can only be clear or unclear, useful or unhelpful.

### Derived (Theorem / Lemma)

Follows logically from primitives + definitions. The derivation is the point. If you can prove it from upstream items, it is not an axiom — it is a result.

Examples from the corpus:

- **Information Primacy** — if derivable from Existence + Distinction + Relation, it is a theorem, not an axiom. The derivation: if things exist (P1) and are distinguishable (P2) and stand in relation (P3), then information exists (distinguishable states in relation = information by definition). That is a derivation. Label it a theorem.
- **"Relabeling preserves bijection"** — this is a lemma, used in larger proofs but not itself a starting point.
- **The product/veto property** — derived from the canonical equation structure. Any zero coordinate gives χ = 0. This is a mathematical consequence, not an axiom.
- **"A system cannot ground itself from inside"** — derivable from Gödel's incompleteness theorems applied to the framework. This is a derived result with external support, not a primitive.
- **The consciousness derivation chain** — if consciousness is derived from the four axioms (L3 = L2 + recursion + A4), then "consciousness exists" is a theorem of the framework, not an axiom of it.

The more items you can move from Primitive to Derived, the stronger the framework becomes. Every item you derive is an item you do not have to assume. A framework with 5 primitives and 50 theorems is enormously stronger than one with 55 axioms, because the 50 theorems carry the authority of the 5 primitives rather than each standing on its own unsupported claim.

### Hypothesized (Empirical / Conjectural)

A falsifiable claim about observed reality. It makes a prediction that could be wrong. It is not accepted as a starting point — it is tested against evidence.

Examples from the corpus:

- **"Observation creates reality"** — this is a physical/metaphysical hypothesis, not a primitive. It requires empirical and interpretive qualification. The corrected reading from the governance meta layer: faith/observation selects the BASIS, never the outcome.
- **"Institutional coherence decays measurably over time"** — this is an empirical hypothesis with a specific prediction (the decade bundles, the Amish control study, the Russia 1991 mortality data). It is testable and it might be wrong.
- **"The Hubble gradient correlates with coherence structure"** — this is the DT-004 pre-registered prediction. It is awaiting data. It is a hypothesis, not a starting point.
- **"Φ > 0 distinguishes conscious from non-conscious"** — this is an empirical claim about consciousness that could be falsified if a system with Φ = 0 is demonstrated to be conscious.
- **"Three-month-old infants demonstrate pre-linguistic moral evaluation"** — this is an empirical claim supported by the Hamlin/Wynn data. It is evidence, not axiom.
- **Any "kill condition" claim** — by definition, a kill condition is a hypothesis about what would falsify something. It is hypothetical.

Hypotheses are the framework's contact with reality. They are where the rubber meets the road. But they are not axioms. They are the things that axioms, definitions, and theorems predict — and if the predictions fail, the hypotheses fail, and we trace the failure back to whichever upstream item produced the wrong prediction.

### Interpreted (Cross-Domain Mapping / Theological Identification)

Associates one formal structure with a concept, entity, or structure in another domain. This is where the framework's bridge claims live — and where the most dangerous overclaims hide.

Examples from the corpus:

- **"Grace = negentropy"** — this is an interpretive mapping from thermodynamics to theology. It is not an axiom. It is a bridge claim that requires its own validation per the bridge schema.
- **"Grace precedes all variables"** — this is either a theological postulate (accepted on confessional grounds) or a model-ordering assumption (accepted for mathematical convenience). Either way, it is not a primitive of the formal system.
- **"Prayer as superposition"** — this is a model analogy unless you independently define a mathematically precise state space and prove the correspondence. It is interpretive.
- **"Father = Source, Son = Logos, Spirit = Relation/Actualization"** — this is a theological identification. It maps formal roles to Trinitarian persons. It is a bridge from theology to mathematics, not an axiom of either.
- **"Sin = noise on the Shannon channel"** — this is an interpretive mapping. Sin in theology and noise in information theory are being identified as the same structural phenomenon. That identification is a claim that must be validated, not a starting point that is assumed.
- **"Logos ↔ information/structure"** — same category. An interpretive identification between a theological concept and a mathematical/physical concept. It may be right. It is not an axiom.

Interpretive mappings are the framework's distinctive contribution — the bridges between physics and theology that nobody else has built. But they are the MOST dangerous items in the corpus if mislabeled as axioms, because an interpretive mapping labeled "axiom" silently transfers theological authority to a physics claim (or vice versa) without anyone noticing. The bridge schema exists precisely to prevent this.

## The Dependency Graph

Once every item is classified, the corpus becomes a dependency graph rather than a flat list:

```
PRIMITIVES (5-9)
    ↓
DEFINITIONS (symbol meanings, conventions)
    ↓
THEOREMS / LEMMAS (derived from primitives + definitions)
    ↓
MODEL LAWS (mathematical relations modeling specific domains)
    ↓
HYPOTHESES (falsifiable predictions)
    ↓
INTERPRETIVE MAPPINGS (cross-domain bridges)
    ↓
THEOLOGICAL IDENTIFICATIONS (confessional claims about what the structures mean)
```

Each level depends on the levels above it. No level inherits the authority of a level it does not derive from. A theological identification does not become a theorem just because it sits in the same corpus as theorems. A hypothesis does not become a primitive just because it is labeled with an axiom ID.

The direction of authority flows DOWNWARD: primitives ground definitions, definitions enable theorems, theorems generate predictions, predictions are tested empirically, and interpretive mappings connect the formal results to theology. The direction of FALSIFICATION flows UPWARD: a failed hypothesis challenges the theorem that predicted it, which challenges the primitive it derived from, which challenges the foundation. But falsification only flows upward through validated derivation chains — not through interpretive mappings, not through analogies, and not through shared vocabulary.

## The Reclassification Protocol

For each of the 190 items:

1. **Read the item.** What does it actually assert?
2. **Ask: can this be derived from other items in the corpus?** If yes → Derived (theorem/lemma). If no → proceed.
3. **Ask: does this fix the meaning of a symbol?** If yes → Definition. If no → proceed.
4. **Ask: does this make a falsifiable prediction about observed reality?** If yes → Hypothesized. If no → proceed.
5. **Ask: does this map a structure from one domain to another?** If yes → Interpreted. If no → proceed.
6. **If none of the above:** it is a candidate Primitive. But verify — try hard to derive it before accepting it as underived.

Each item retains its legacy ID for continuity:

```
legacy_id: A5.1
logical_status: empirical_hypothesis
```

No renumbering. No disruption to existing references. The classification changes; the ID does not.

## What This Enables

Once the reclassification is complete:

1. **Axiom minimization becomes possible.** You cannot minimize the axioms until you stop calling non-axioms axioms. With 190 "axioms" you cannot reduce. With 5-9 primitives and 181+ derived/defined/hypothesized/interpreted items, you can ask: can I derive this primitive from those other primitives? Each successful derivation reduces the primitive count by one.

2. **Lean formalization becomes tractable.** Lean can verify theorems derived from stated axioms. It cannot verify interpretive mappings or theological identifications. The reclassification tells you exactly which items are Lean-ready (primitives, definitions, theorems) and which are not (hypotheses, interpretations).

3. **The framework becomes defensible.** A critic who says "your framework has 190 unsupported assumptions" is attacking a real weakness if all 190 are labeled axioms. A framework with 5 primitives, 30 definitions, 50 theorems, 40 hypotheses, and 65 interpretive mappings is a different kind of object. The primitives are few enough to examine one by one. The theorems carry the authority of their derivations. The hypotheses are testable. The interpretive mappings are explicitly labeled as bridges requiring independent validation. Nothing is hiding.

4. **Overclaim detection becomes automatic.** If an item classified as "interpretive mapping" is being used downstream as if it were a "primitive," the system flags it. If an item classified as "hypothesis" is being cited as "proven," the system flags it. The classification IS the overclaim filter.

5. **The governance documents become enforceable.** The claim type policy (D/C/E/P/H/T/A/O) maps directly onto the five buckets. The bridge schema maps directly onto the Interpreted bucket. The physics atom schema maps directly onto the Hypothesized bucket. The reclassification is not a new rule — it is the rule the governance documents already require, applied to the framework's own internal corpus.

## The Legacy ID Crosswalk

The reclassification does not delete, renumber, or rewrite any existing item. It adds a field:

```yaml
legacy_id: A5.1
legacy_label: "Observation Requirement"
logical_status: empirical_hypothesis
reclassification_note: "Originally labeled axiom. Reclassified because the claim that observation creates/actualizes reality is a falsifiable physical and metaphysical hypothesis, not an underived starting point. The corrected reading (governance meta layer): observation selects the basis, never the outcome."
```

Every item in the corpus gets this treatment. The legacy ID stays. The new classification says what the item actually is. The reclassification note says why the change was made. Nothing is lost. Everything is clarified.

## The Bottom Line

You do not have 190 axioms. You have approximately:

- **5-9 primitives** (the actual bedrock)
- **30-40 definitions** (symbol meanings and conventions)
- **40-50 derived results** (theorems and lemmas)
- **30-40 empirical hypotheses** (testable predictions)
- **40-50 interpretive mappings** (cross-domain bridges and theological identifications)
- **10-20 conjectures** (proposed but unproven results)

That is a framework. The old list was a collection of important statements mislabeled as a foundation.

The single most important thing you can do before any further formalization is classify every item honestly. The framework does not get weaker when you stop calling hypotheses axioms. It gets enormously stronger — because now the actual axioms carry the full weight of being genuinely primitive, and everything else carries the appropriate weight of being derived, tested, or interpreted.

You cannot minimize the axioms until you stop calling non-axioms axioms.

Start there.

---

*Rewritten and extended from the original Atoxor Ltd. analysis | POF 2828 | August 13, 2026*
